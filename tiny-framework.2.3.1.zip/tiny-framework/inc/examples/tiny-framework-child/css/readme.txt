Do not forget to replace original style.css file with the generated one 
or set the output path of the compiler to main child theme folder.

Don't know how to use LESS dynamic stylesheet language? Start reading here:

	http://webdesign.tutsplus.com/tutorials/htmlcss-tutorials/get-into-less-the-programmable-stylesheet-language/

Also see this video about LESS and other CSS preprocessors:

	http://www.youtube.com/watch?v=FlW2vvl0yvo

GUI compilers that use LESS (I prefer SimpLESS):

	https://github.com/less/less.js/wiki/GUI-compilers-that-use-LESS.js

General information about LESS:

	http://lesscss.org